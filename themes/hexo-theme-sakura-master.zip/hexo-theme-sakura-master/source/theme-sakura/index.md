---
title: theme-sakura
comments: false
date: 2019-01-04 22:53:25
keywords: Hexo 主题 Sakura 🌸
description:
photos: https://static.2heng.xin/wp-content/uploads//2018/05/sakura2.jpeg
---
Hexo主题Sakura修改自WordPress主题[Sakura](https://github.com/mashirozx/Sakura/)，感谢原作者[Mashiro](https://2heng.xin/)